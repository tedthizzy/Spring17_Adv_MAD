//
//  Details_ViewController.swift
//  Realm Demo
//
//  Created by Matt Dickey on 2/22/17.
//  Copyright © 2017 Matt Dickey. All rights reserved.
//

import UIKit

class Details_ViewController: UIViewController {

    @IBOutlet weak var blurryBackgroundImageView: UIImageView!
    @IBOutlet weak var heroImageView: UIImageView!
    @IBOutlet weak var songTitleLabel: UILabel!
    @IBOutlet weak var artistLabel: UILabel!
    @IBOutlet weak var albumLabel: UILabel!
    
    // This will be the Song that is sent from the TableView when it is tapped
    var songForDetail : Song?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Check to make sure the previous screen sent a Song object
        if let song = songForDetail {
            self.title = songForDetail?.title
            blurryBackgroundImageView.image = UIImage(named: song.imageName)
            heroImageView.image = UIImage(named: song.imageName)
            songTitleLabel.text = song.title
            artistLabel.text = song.artist
            albumLabel.text = song.album
        }

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
