//
//  AddNew_ViewController.swift
//  Realm Demo
//
//  Created by Matt Dickey on 2/22/17.
//  Copyright © 2017 Matt Dickey. All rights reserved.
//

import UIKit
import RealmSwift

class AddNew_ViewController: UIViewController, UITextFieldDelegate , UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var songTextField: UITextField!
    @IBOutlet weak var artistTextField: UITextField!
    @IBOutlet weak var albumTextField: UITextField!
    @IBOutlet weak var imagePickerView: UIPickerView!
    
    
    // Array of imageNames corresponding to the name found in assets.xcassets
    let imageNames = [" ", "Dre", "Zeppelin", "Michael Jackson", "Rick Rolled"]
    
    //the new Song object that will eventually be stored in the database
    var newSong = Song()
    
    @IBAction func saveTapped(_ sender: Any) {
        
        // If any of the fields are empty, alert the user
        if  (songTextField.text?.isEmpty)! || (artistTextField.text?.isEmpty)! || (albumTextField.text?.isEmpty)! {
            let alert = UIAlertController(title: "Wait", message: "You must fill out the entire form", preferredStyle: UIAlertControllerStyle.alert)
            
            //add an "Okay" button to the alert controller
            let okayAction = UIAlertAction(title: "Okay", style: UIAlertActionStyle.default, handler: nil)
            alert.addAction(okayAction)
            
            //present the Alert
            self.present(alert, animated: true, completion: nil)
            
        } else {
            //otherwise initiate the new Song object
            newSong.title = songTextField.text!
            newSong.artist = artistTextField.text!
            newSong.album = albumTextField.text!
            
           try! realm.write {
                realm.add(newSong)
            }
            
            //Go back to the TableView with the manually created segue
            performSegue(withIdentifier: "backToHomeScreen", sender: nil)
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Make Keyboard disappear when Return key is tapped
        songTextField.delegate = self
        artistTextField.delegate = self
        albumTextField.delegate = self
        
        imagePickerView.dataSource = self
        imagePickerView.delegate = self
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //PickerView Things
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return imageNames.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return imageNames[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        newSong.imageName = imageNames[row]
    }
    

    
    // Keyboard Things
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    
}
