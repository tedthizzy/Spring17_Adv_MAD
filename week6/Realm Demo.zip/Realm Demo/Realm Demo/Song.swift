//
//  Song.swift
//  Realm Demo
//
//  Created by Matt Dickey on 2/22/17.
//  Copyright © 2017 Matt Dickey. All rights reserved.
//

import Foundation
import RealmSwift

class Song : Object {
    
    dynamic var title = String()
    dynamic var artist = String()
    dynamic var album = String()
    dynamic var imageName = " "
    
}
