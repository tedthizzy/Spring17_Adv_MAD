//
//  HomeScreen_TableViewController.swift
//  Realm Demo
//
//  Created by Matt Dickey on 2/22/17.
//  Copyright © 2017 Matt Dickey. All rights reserved.
//

import UIKit
import RealmSwift

class HomeScreen_TableViewController: UITableViewController {
    
    
    // Get list of all items in the database of type: Song
    var allSongs = realm.objects(Song.self)
    // Song variable that will be sent to the Detail View Controller
    var selectedSong : Song?
    
    // method responsible for refreshing the databse and table simultaneously.
    func readAndUpdate(){
        allSongs = realm.objects(Song.self)
        tableView.reloadData()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        readAndUpdate()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //Manually created segue so that we can move from the other storyboards back to home.
    @IBAction func unwindtoHomeScreen(segue: UIStoryboardSegue){
        readAndUpdate()
    }

    // MARK: - TableView Things

    override func numberOfSections(in tableView: UITableView) -> Int {

        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allSongs.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)

        // Configure the cell...
        let song = allSongs[indexPath.row]
        
        cell.textLabel?.text = song.title
        cell.detailTextLabel?.text = song.artist

        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedSong = allSongs[indexPath.row]
        
        //See prepare(for segue) for more
        performSegue(withIdentifier: "showDetail", sender: nil)
    }


    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            try! realm.write {
                realm.delete(allSongs[indexPath.row])
            }
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    
    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        if segue.identifier == "showDetail"{
            let detailScreen = segue.destination as! Details_ViewController
            detailScreen.songForDetail = selectedSong
        }
    }
    

}
